<script src="{{ URL::asset('assets/js/vendor.min.js') }}"></script>
@yield('script')
<script src="{{ URL::asset('assets/js/app.min.js') }}"></script>
@yield('script-bottom')