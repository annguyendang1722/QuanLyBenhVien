<!-- Footer Start -->
<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
				{{ date('Y') }}  &copy; Phần mềm quản lý lịch khám. Trung tâm hô hấp - Bệnh viện Bạch Mai
            </div>
        </div>
    </div>
</footer>
<!-- end Footer -->